# @tare/contract

Version 0.7.1 separates exact upload documents from stable public read types. It contains browser-safe Zod schemas, a typed fetch client, fictional fixtures, OpenAPI 3.1, and generated JSON Schema (draft 2020-12). Build with `npm.cmd run build --workspace @tare/contract` from `backend/`. The backend packaging script creates the tarball under `contract/pack/`; copy it into the site's own `vendor/` before installing it.

```ts
import { createClient, ApiClientError } from '@tare/contract'
const api = createClient('http://127.0.0.1:7810')
const benchmark = await api.bench()
const sampled = await api.weigh(program, { fixture: 'anchor' })
```

The client validates responses. Failures throw `ApiClientError` with `code`, `status`, and the engine's `body.error` envelope. Ordinary empty lists, `not_program`, `no_transactions`, `sampling`, and `report_unavailable` detail states remain successful responses. Every client method accepts per-call `fixture`, `signal` and headers. Fixture data is exported from `@tare/contract/fixtures`; all fixture program identities and weights are fictional. `fixture: true` on benchmark and compatibility documents marks that fact.

## Document semantics

- `schemaVersion: "1"` versions the three file formats independently of the npm package. `Weighing` describes `weigh.json`; `ProofReport` describes `proof.json` and pinned reports. The latter requires a proof. A weighing before proof has `proof: null`.
- `Weighing.optimization` is optional and nullable. Its known fields match `tare-opt::Stats` plus input/output hashes; newer compaction counters and `pcMap` are optional for older outputs. Unknown optimizer fields are preserved. `Weighing.recordedCorpus` is optional and nullable, accepting the Rust writer's array of provenance objects. Each entry records corpus/build hashes, whether the stock binary matches, and validator reproduction counts plus a required, nullable JSON `firstDifference`. Unknown fields on the optimizer and each provenance object are preserved, including arbitrary JSON values under those keys. Validator reproduction and all other document and API objects remain strict. `ProofReport` accepts the same fields.
- `Weighing.replay` is optional and, when present, is a strict `{ encoding: "gzip+base64", sha256, data }` object. Its hash covers the exact decompressed UTF-8 JSON bytes of the replay bundle and is the proof's combined corpus hash. Full new attestation reports retain this payload; old reports and benchmark summaries may omit it. The backend preserves these bytes; the CLI verifies and replays them rather than resampling. Replay consumers cap decompression at 256 MiB. The existing upload body limit still applies to the complete compressed report.
- `RegistryTotals.feesAccruedLamports` is always present, in lamports. It is the fee vault's balance above the rent-exempt minimum for its zero-data account, not a sum of inferred fees from records. Fixture and empty responses report zero.
- Upload schemas are named `UploadWeighing`, `UploadProofReport` and `UploadFlagInput`. They preserve safe integer numbers and canonical decimal strings exactly, including full u64 and signed i64 ranges. They do not coerce or transform values. Use them to validate stored bytes and CLI uploads. The typed client's upload methods accept these schemas; read methods return the established public types.
- Public read schemas retain the established names `Weighing`, `ProofReport`, `FlagInput`, `Build` and `WeighingTotals`. They return safe numeric weights, sizes, rent totals, input counts, proof counts, trace counters and slots. Safe decimal strings are converted to numbers, including benchmark aggregates, test-suite counts and registry counts; values outside the safe integer range fail validation rather than being rounded. Account balances (`lamports` in replay accounts and lamports differences) and account `rentEpoch` values always read as canonical decimal strings, including values supplied as safe numbers.
- The compressed replay bundle remains opaque and unchanged. Unknown optimizer and provenance extension data remains intact. These schemas add optional `buildEnvironment` (`{ kind: "host", targetTriple }` or `{ kind: "image", image }`) and `accountAbi` (`{ mode: "raw" | "sdk", selection }`) as emitted by the toolchain.

- Instruction `gross` and `net` are **median compute units per successful measured call**; `inputs` is the number of successful calls measured on both builds. `tare = gross - net`. A row with `inputs: 0` has `gross`, `net`, and `tare` all null: the instruction was not successfully reached, so it contributes nothing to totals. A positive-input row requires all three integer weights.
- Weighing totals sum one median gross/net/tare value per reached instruction, independent of how many calls measured that instruction; totals `inputs` sums the successful measured call counts. Thus totals are a comparison across reached instructions, not the sum of compute spent over the corpus. Benchmark weight totals sum measured program totals, and `totals.instructions` counts reached instructions. Not-built programs contribute only to `programs` and `notBuilt`. Size and rent totals use gross for the stock build and net for the Tare build. JSON Schema cannot express arithmetic across fields; producers must enforce these identities.
- Test suite `ran = passed + failed`. Proof corpus counts count inputs by origin; `comparisons.inputs` counts inputs actually compared before success or first divergence. Individual comparison counters count comparisons actually made. Proof status `matched` requires `firstDivergence: null`; `diverged` requires the first input and at least one typed difference. An account absent on either side uses null in the difference.
- Replay inputs contain the transaction bytes and pre-execution account snapshots, plus the sampled slot when known. Each difference identifies account bytes, lamports, account metadata, logs, return data or errors. Account metadata differences contain nullable `{ owner, executable, rentEpoch }` snapshots; replay input account snapshots may also include `rentEpoch`. Transaction errors preserve their JSON representation. The fixture transaction bytes decode to a label and cannot execute on Solana.
- Measured benchmark rows retain `record: string | null` and may include `recordCluster: string`. The API adds an absolute `recordUrl` only when it resolves an attachment in the configured registry cluster; an unresolved attachment remains visible without a link.
- Unknown program names/addresses and source metadata are explicitly null. A `not_built` program's `construct` is null only for a build failure unrelated to an unsupported construct; its `reason` always explains the failure.
- Compatibility construct names are nonempty strings so the toolchain can name newly covered syntax without another contract release. The exported `CONSTRUCTS` list contains the initial examples, not a closed vocabulary. Each matrix entry gives a supported boolean and IDs of corpus programs exercising it for one exact Anchor version. An absent benchmark or matrix is an empty document with null generation metadata, never fixture data.
- `ProgramSample` is observed deployed-program compute, distinct from a paired build weighing. `share` is a fraction from 0 to 1 of measured program compute; median and p90 are integer CU. A null instruction name is rendered using its hexadecimal discriminator.
- `ProgramSample.signaturesExamined` counts signature rows examined during the sampling run, including rows that did not yield a measured transaction. Every new sample includes this count. It is optional only for compatibility with older recordings: an absent value means unknown, never zero. `transactions` still counts transactions with accepted compute measurements.

## Rust consumers

Validate produced upload files against `schema/UploadWeighing.json`, `schema/UploadProofReport.json` and `schema/UploadFlagInput.json`. The established `Weighing.json`, `ProofReport.json`, `FlagInput.json`, `Build.json` and `WeighingTotals.json` describe normalized public read outputs. Benchmark and compatibility files use `schema/BenchResults.json` and `schema/Compat.json`. The schemas and `openapi.json` are generated directly from Zod in the package build. POST a ProofReport directly as JSON to `/v1/reports`, and a FlagInput directly to `/v1/flag-inputs`; both return `{ hash, location }`. Hash is lowercase SHA-256 of the exact stored UTF-8 JSON bytes. Read them back through `/v1/reports/{hash}` or `/v1/flag-inputs/{hash}`. Send `Accept: application/json` for normalized public read values. Omit that header, or request `application/octet-stream`, to receive the exact uploaded bytes for content-hash verification. The typed client selects JSON automatically; CLI hash verification uses the raw representation. Responses vary on `Accept`. GET `/v1/config` supplies nullable `installLine` for the site's CLI installation command and `recordUrlTemplate` for the line printed by `tare attest`; substitute the newly created record address for `{record}`. No Pinata key belongs in the CLI.

## Changes from 0.1.0

Instruction weights changed from cumulative CU to per-call medians. Unreached instructions now carry zero inputs and null weights, and are omitted from weight totals. Compatibility construct names now accept any nonempty string. The document envelope remains `schemaVersion: "1"`; consumers must update to the 0.2.0 package and matching schemas together. The 0.1.0 and 0.2.0 tarballs are retained under `pack/`.

## Changes from 0.2.0

`ProgramSample.signaturesExamined` is an additive optional integer. Existing 0.2.0 recordings remain valid without it and are preserved unchanged. New producers must emit the count, and clients must display an omitted count as unknown. The 0.3.0 tarball is published locally alongside the previous versions in `pack/`.

## Changes from 0.3.0

Optional `optimization` and `recordedCorpus` fields preserve the Rust writer's extension data without weakening other schemas. Missing fields remain missing; explicit null remains null. Recorded-corpus writers emit a provenance array (empty when no recordings were replayed). Singleton provenance objects are not accepted. Existing recorded fixtures and all prior tarballs are retained unchanged.

## Changes from 0.4.0

Optional `replay` is retained in strict weighings, proof uploads and reads. `Replay` is exported as a schema and type, with `schema/Replay.json` for Rust consumers. `RegistryTotals` now requires `feesAccruedLamports`; every new API response supplies it. Flag differences additionally accept strict account metadata comparisons, and replay account snapshots accept an optional safe-integer `rentEpoch`. Prior tarballs and recorded mainnet samples remain unchanged.

## Changes from 0.5.0

`PublicConfig.installLine` is a required, nullable string; the API supplies the installation command when configured. OpenAPI also describes the raw `/install.sh` shell response and `/releases/{file}` download responses. These routes do not take fixture scenarios. Uploaded replay and flag input u64 fields now accept safe integer numbers or exact u64 decimal strings without changing their representation: account `lamports`/`rentEpoch`, input `slot`, lamports difference values and metadata difference `rentEpoch`. Other numeric fields retain their existing types. All older tarballs and recorded mainnet files remain unchanged.

## Changes from 0.6.0

Measured benchmark rows accept optional `recordCluster` and absolute `recordUrl`. Uploaded proof schemas now preserve exact u64 decimal strings throughout the typed report, including large signed tare values as i64 strings. Public aggregate count fields remain numbers. All existing document shapes remain strict except optimizer and provenance extensions. Prior tarballs and recorded mainnet files remain unchanged.

## Changes from 0.7.0

Uploads and public reads now use separate schemas. Public numeric fields infer as `number`, while account balances and epochs infer as `string`; upload unions retain their original representation. New `Upload*` JSON Schemas describe wire uploads. Optional build environment and account ABI metadata is retained. Compile-time assertions in `src/type-assertions.ts` keep reached-instruction arithmetic, build sizes, all weighing totals, record details, corpus counts, slots and read account amounts stable.
